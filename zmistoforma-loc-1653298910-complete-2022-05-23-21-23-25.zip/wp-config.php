<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры базы данных: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'zmistoforma_db' );

/** Имя пользователя базы данных */
define( 'DB_USER', 'root' );

/** Пароль к базе данных */
define( 'DB_PASSWORD', '' );

/** Имя сервера базы данных */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'A*56hlZV+S81!ZaO$Z]flU/38,;-X}]s.MrxGkdv7G8oEZE{iCXfoWB8hfsTtNd>' );
define( 'SECURE_AUTH_KEY',  'Z$HGw0}l4rqX]-zq/^84{J`Rm#T^|OSWav0;)z-+n57fhsq.o Q)]?v*WQenD[8v' );
define( 'LOGGED_IN_KEY',    'YF/+XiF2kz@_Zb59BQiAX697*l!=%=J=Jf3vv=zw@dyB(No7I w$tv_3Z%X(4!T4' );
define( 'NONCE_KEY',        '45?pP!899Jz;)o*!nt@Ub/<]zp9Afx6BbS@vA^XB{8Lv3[<7Cf?Z=oGiW]v &sG1' );
define( 'AUTH_SALT',        '915? _OQ#B9&flq*5c}nw a*|EhHyz@n(t@HgE<!4`0>f^hFgWA%;4=R/)kR#=5D' );
define( 'SECURE_AUTH_SALT', 'Mz/r~fK)lmWvcvfQg#h1P;TgL+F)q;1<IOx-Ahlyf`}3X>&ZfGCXiSsfK&{;7,Qt' );
define( 'LOGGED_IN_SALT',   'v!kdD-aAtd!>DB~k2Rg0uU>.d(7>CwD8!h3kk_JH81MZjS#sRXf.th/H2Y6+Y,>D' );
define( 'NONCE_SALT',       'gjrP`1H-:%%QK<&9vsk*!`8cwSb2HxQaa)Cktd 9a$UkkJz@pSKqk#z[)XlB?*yJ' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
